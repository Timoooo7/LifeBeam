package com.example.lifebeam.data.local.model

data class UserModel(
    val uid: String,
    val name: String,
    val email: String,
    val photo: String,
    val phone: String,
    val isLogin: Boolean = false,
)
