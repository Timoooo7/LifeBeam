package com.example.lifebeam.ui.main

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.net.http.UrlRequest.Status
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.service.carrier.CarrierMessagingService.ResultCallback
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.ActionBar
import androidx.lifecycle.MutableLiveData
import com.example.lifebeam.R
import com.example.lifebeam.data.local.model.UserModel
import com.example.lifebeam.databinding.ActionBarBinding
import com.example.lifebeam.ui.auth.LoginActivity
import com.example.lifebeam.databinding.ActivityMainBinding
import com.example.lifebeam.ui.utils.ViewModelFactory
import com.google.android.gms.auth.api.Auth
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    private lateinit var mainActivityBinding: ActivityMainBinding
    private lateinit var auth: FirebaseAuth
    private val mainViewModel: MainViewModel by viewModels {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /* Auth Check */
        auth = Firebase.auth
        val firebaseUser = auth.currentUser
        if (firebaseUser == null) {
            // Not signed in, launch the Login activity
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

//        mainViewModel.getSession().observe(this){ user ->
//            if(!user.isLogin) {
//                startActivity(Intent(this, LoginActivity::class.java))
//                finish()
//            }else{
//                _user.value = user
//            }
//        }

        /* Set view */
        mainActivityBinding = ActivityMainBinding.inflate(layoutInflater)
        val actionBarBinding: ActionBarBinding =ActionBarBinding.inflate(layoutInflater)
        supportActionBar?.displayOptions = ActionBar.DISPLAY_SHOW_CUSTOM
        supportActionBar?.customView = actionBarBinding.root
        setContentView(mainActivityBinding.root)

        /* Set Action Bar */
        supportActionBar?.elevation = 10f
        actionBarBinding.apply {
            tvTittle.text = getString(R.string.app_name)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.btn_logout -> {
                signOut()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun signOut() {
        auth.signOut()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}